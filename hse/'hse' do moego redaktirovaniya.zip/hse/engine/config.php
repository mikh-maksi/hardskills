<?php
    $config["server"] = "goitnscl.mysql.tools";
    $config["login"] = "goitnscl_hse";
    $config["pass"] = "R_10dz(Kc0";
    $config["db"] = "goitnscl_hse";

?>