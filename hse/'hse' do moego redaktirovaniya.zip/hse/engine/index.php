<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="index">
    <h2>HR-специалисты</h2>
        <a href="http://goiteens.club/hse/registration.php" target="_blank">Регистрация</a>
        <a href="http://goiteens.club/hse/profile.php" target="_blank">Профиль</a>
        <a href="http://goiteens.club/hse/search.php" target="_blank">Поиск студентов</a>
        <a href="http://goiteens.club/hse/students.php" target="_blank">Студенты у HR</a>
        <a href="http://goiteens.club/hse/student-highslide.php" target="_blank">Всплывающий блок на студенте для HR</a>

    <h2>Адмистратор</h2>
    <a href="http://goiteens.club/hse/adminHR.php" target="_blank">Верификация HR</a>
        <a href="http://goiteens.club/hse/adminstudents.php" target="_blank">Список студентов</a>
        <a href="http://goiteens.club/hse/adminstudentprofile.php" target="_blank">Профиль студента</a>
        <a href="http://goiteens.club/hse/adminHR.php" target="_blank">Список HR-специалистов</a>
        <a href="http://goiteens.club/hse/adminHR-highslide.php" target="_blank">Список HR-специалистов. Всплывающее.</a>  
        <a href="http://goiteens.club/hse/adminHR-highslide.php" target="_blank">Список HR-специалистов. Всплывающее.</a>  
        <a href="http://goiteens.club/hse/adminHR-highslide.php" target="_blank">Список HR-специалистов. Всплывающее.</a>  
        <a href="http://goiteens.club/hse/adminHR-highslide.php" target="_blank">Список HR-специалистов. Всплывающее.</a>  
        <a href="http://goiteens.club/hse/hr-student-highslide.php" target="_blank">Всплывающий блок на студенте для HR</a>
        <a href="http://goiteens.club/hse/balanse.php" target="_blank">Баланс HR</a>

    </div>
</body>
</html>
