<div class=" d-flex justify-content-between statistics">
                    <div class="border col-2 text-center text-monospace">Статистика</div>
                    <div class="border col-2 text-center text-monospace">Осталось: <br> 7</div>
                    <div class="border col-2 text-center text-monospace">Стажировка:<br>  0</div>
                    <div class="border col-2 text-center text-monospace">Нанято: <br> 0</div>
                    <div class="border col-2 text-center text-monospace">Баланс: <br> 300 грн.</div>
                </div>