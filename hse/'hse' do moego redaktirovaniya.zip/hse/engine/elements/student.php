<div class="student col-3 border d-flex flex-column  align-items-center mt-2 rounded">
    <div class="col-10 border text-center">ID</div>
    <div class="col-10 border text-center mt-2">ФИО</div>
    <div class="col-10 border text-center mt-2">20.02.20</div>
    <div class="col-12  text-right mt-2">
        <button class = "btn border btn-outline-dark btn-sm">Подробнее</button>
    </div>
</div>
